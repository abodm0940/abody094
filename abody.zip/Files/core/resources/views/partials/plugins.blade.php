@php echo  analytics() @endphp
