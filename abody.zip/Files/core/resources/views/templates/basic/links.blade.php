@extends($activeTemplate.'layouts.master')
@section('content')
<div class="dashboard-section ptb-80">
    <div class="container">
        <div class="wb-break-all">@php echo (@$description) @endphp</div>
    </div>
</div>
@endsection



